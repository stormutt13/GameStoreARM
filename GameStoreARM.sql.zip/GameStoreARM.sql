-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Хост: 127.0.0.1:3306
-- Время создания: Апр 10 2023 г., 18:02
-- Версия сервера: 5.7.39
-- Версия PHP: 8.0.22

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- База данных: `GameStoreARM`
--

-- --------------------------------------------------------

--
-- Структура таблицы `devs`
--

CREATE TABLE `devs` (
  `id` int(11) NOT NULL COMMENT 'Идентификатор',
  `name` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'Наименование'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='Разработчики';

--
-- Дамп данных таблицы `devs`
--

INSERT INTO `devs` (`id`, `name`) VALUES
(4, 'Crytek'),
(5, 'EXBO'),
(3, 'Facepunch Studio'),
(2, 'Motion Twin'),
(7, 'Re-Logic'),
(6, 'Respawn Entertainment'),
(1, 'Valve');

-- --------------------------------------------------------

--
-- Структура таблицы `games`
--

CREATE TABLE `games` (
  `id` int(11) NOT NULL COMMENT 'Идентификатор',
  `name` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'Название игры',
  `genre` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'Жанр',
  `dev` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'Разработчик',
  `platform` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'Тип платформы',
  `rating` float NOT NULL COMMENT 'Рейтинг игры',
  `type` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'Тип продукта',
  `price` int(11) NOT NULL COMMENT 'Цена'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='Каталог игр';

--
-- Дамп данных таблицы `games`
--

INSERT INTO `games` (`id`, `name`, `genre`, `dev`, `platform`, `rating`, `type`, `price`) VALUES
(2, 'Dead Cells', 'Инди', 'Motion Twin', 'PS5', 7.7, 'Ключ PSN', 1800),
(3, 'Rust', 'Приключение', 'Facepunch Studio', 'PC', 6.4, 'Ключ Steam', 1100),
(4, 'Crysis 3', 'Шутер', 'Crytek', 'PC', 6.8, 'Box', 800);

-- --------------------------------------------------------

--
-- Структура таблицы `genres`
--

CREATE TABLE `genres` (
  `id` int(11) NOT NULL COMMENT 'Идентификатор',
  `name` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'Наименование'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='Жанры игр';

--
-- Дамп данных таблицы `genres`
--

INSERT INTO `genres` (`id`, `name`) VALUES
(3, 'Инди'),
(4, 'Приключение'),
(6, 'Стратегия'),
(2, 'Шутер'),
(1, 'Экшен');

-- --------------------------------------------------------

--
-- Структура таблицы `platforms`
--

CREATE TABLE `platforms` (
  `id` int(11) NOT NULL COMMENT 'Идентификатор',
  `name` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'Наименование '
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='Платформа игры';

--
-- Дамп данных таблицы `platforms`
--

INSERT INTO `platforms` (`id`, `name`) VALUES
(1, 'PC'),
(3, 'PS4'),
(2, 'PS5'),
(4, 'Xbox One'),
(5, 'Xbox Series X');

-- --------------------------------------------------------

--
-- Структура таблицы `sold`
--

CREATE TABLE `sold` (
  `id` int(11) NOT NULL COMMENT 'Идентификатор',
  `date` datetime NOT NULL COMMENT 'Дата продажи',
  `game` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'Игра',
  `user` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'Продавец',
  `price` int(11) NOT NULL COMMENT 'Цена'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='Проданные товары';

--
-- Дамп данных таблицы `sold`
--

INSERT INTO `sold` (`id`, `date`, `game`, `user`, `price`) VALUES
(1, '2023-04-10 15:26:58', 'Rust', 'Титов Марк Александрович', 1100);

-- --------------------------------------------------------

--
-- Структура таблицы `types`
--

CREATE TABLE `types` (
  `id` int(11) NOT NULL COMMENT 'Идентификатор',
  `name` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'Наименование'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='Тип платформы';

--
-- Дамп данных таблицы `types`
--

INSERT INTO `types` (`id`, `name`) VALUES
(3, 'Box'),
(4, 'Аккаунт Origin'),
(5, 'Ключ PSN'),
(1, 'Ключ Steam'),
(2, 'Эксклюзивное издание');

-- --------------------------------------------------------

--
-- Структура таблицы `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL COMMENT 'Идентификатор',
  `fio` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'ФИО',
  `login` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'Логин',
  `password` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'Пароль',
  `role` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'Роль'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='Пользователи';

--
-- Дамп данных таблицы `users`
--

INSERT INTO `users` (`id`, `fio`, `login`, `password`, `role`) VALUES
(1, 'Титов Марк Александрович', 'mtita', '44F73E321EEE63688C453479C7192943', 'Администратор'),
(2, 'Гузь Андрей Викторович', 'gusandrey', '1D415B208ADC908FA434CBEB9AF6485D', 'Кассир'),
(3, 'Сергеев Сергей Сергеевич', 'serega12', '202CB962AC59075B964B07152D234B70', 'Работник');

--
-- Индексы сохранённых таблиц
--

--
-- Индексы таблицы `devs`
--
ALTER TABLE `devs`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `name` (`name`);

--
-- Индексы таблицы `games`
--
ALTER TABLE `games`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `name` (`name`),
  ADD KEY `FK_games_devs` (`dev`),
  ADD KEY `FK_games_genres` (`genre`),
  ADD KEY `FK_games_platforms` (`platform`),
  ADD KEY `FK_games_types` (`type`),
  ADD KEY `price` (`price`);

--
-- Индексы таблицы `genres`
--
ALTER TABLE `genres`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `name` (`name`);

--
-- Индексы таблицы `platforms`
--
ALTER TABLE `platforms`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `name` (`name`);

--
-- Индексы таблицы `sold`
--
ALTER TABLE `sold`
  ADD PRIMARY KEY (`id`),
  ADD KEY `FK_sold_games` (`game`),
  ADD KEY `FK_sold_users` (`user`),
  ADD KEY `FK_sold_games_2` (`price`);

--
-- Индексы таблицы `types`
--
ALTER TABLE `types`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `name` (`name`);

--
-- Индексы таблицы `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `login` (`login`),
  ADD KEY `fio` (`fio`);

--
-- AUTO_INCREMENT для сохранённых таблиц
--

--
-- AUTO_INCREMENT для таблицы `devs`
--
ALTER TABLE `devs`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'Идентификатор', AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT для таблицы `games`
--
ALTER TABLE `games`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'Идентификатор', AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT для таблицы `genres`
--
ALTER TABLE `genres`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'Идентификатор', AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT для таблицы `platforms`
--
ALTER TABLE `platforms`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'Идентификатор', AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT для таблицы `sold`
--
ALTER TABLE `sold`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'Идентификатор', AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT для таблицы `types`
--
ALTER TABLE `types`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'Идентификатор', AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT для таблицы `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'Идентификатор', AUTO_INCREMENT=4;

--
-- Ограничения внешнего ключа сохраненных таблиц
--

--
-- Ограничения внешнего ключа таблицы `games`
--
ALTER TABLE `games`
  ADD CONSTRAINT `FK_games_devs` FOREIGN KEY (`dev`) REFERENCES `devs` (`name`) ON UPDATE CASCADE,
  ADD CONSTRAINT `FK_games_genres` FOREIGN KEY (`genre`) REFERENCES `genres` (`name`) ON UPDATE CASCADE,
  ADD CONSTRAINT `FK_games_platforms` FOREIGN KEY (`platform`) REFERENCES `platforms` (`name`) ON UPDATE CASCADE,
  ADD CONSTRAINT `FK_games_types` FOREIGN KEY (`type`) REFERENCES `types` (`name`) ON UPDATE CASCADE;

--
-- Ограничения внешнего ключа таблицы `sold`
--
ALTER TABLE `sold`
  ADD CONSTRAINT `FK_sold_games` FOREIGN KEY (`game`) REFERENCES `games` (`name`) ON UPDATE CASCADE,
  ADD CONSTRAINT `FK_sold_games_2` FOREIGN KEY (`price`) REFERENCES `games` (`price`) ON DELETE NO ACTION ON UPDATE CASCADE,
  ADD CONSTRAINT `FK_sold_users` FOREIGN KEY (`user`) REFERENCES `users` (`fio`) ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
